import React, { useEffect, useMemo, useRef, useState } from "react";

const SOURCE_VALIDATION_RULES = {
  minimumOfficialConfirmations: 2,
  allowPublicationWithoutOfficialSource: false,
  requireCrossCheck: true,
  priorityOrder: ["WHO", "PAHO", "Ministero della Salute", "Istituto Sanitario Nazionale", "CDC", "ECDC"]
};

const SOURCES = [
  { name: "World Health Organization (WHO) - Disease Outbreak News", type: "official global health authority", refresh: "hourly", notes: "Global outbreak notices, laboratory confirmations, international transmission monitoring and travel-related risk assessment." },
  { name: "Pan American Health Organization (PAHO/WHO)", type: "official regional health authority", refresh: "hourly", notes: "Regional epidemiological alerts and hantavirus surveillance coordination across the Americas." },
  { name: "Argentina - Ministerio de Salud de la Nación", type: "official national health authority", refresh: "hourly", notes: "Boletín Epidemiológico Nacional (BEN), hantavirus surveillance, provincial case aggregation and mortality monitoring." },
  { name: "Chile - Ministerio de Salud (MINSAL)", type: "official national health authority", refresh: "hourly", notes: "Confirmed hantavirus cases, epidemiological week updates, ICU status and mortality reports." },
  { name: "Chile - Instituto de Salud Pública (ISP)", type: "official laboratory authority", refresh: "hourly", notes: "National laboratory confirmation and genomic surveillance for hantavirus strains including Andes virus." },
  { name: "United States - CDC Hantavirus Surveillance", type: "official national health authority", refresh: "hourly", notes: "Imported cases, travel advisories, rodent surveillance and clinical guidance." },
  { name: "European Centre for Disease Prevention and Control (ECDC)", type: "official international agency", refresh: "hourly", notes: "Travel-related cluster investigations and European epidemiological monitoring." },
  { name: "Brazil - Ministério da Saúde", type: "official national health authority", refresh: "hourly", notes: "Hantavirus cardiopulmonary syndrome surveillance, zoonotic monitoring and regional notifications." },
  { name: "Paraguay - Ministerio de Salud Pública y Bienestar Social", type: "official national health authority", refresh: "hourly", notes: "Cross-border surveillance with Argentina and regional outbreak monitoring." },
  { name: "Uruguay - Ministerio de Salud Pública", type: "official national health authority", refresh: "hourly", notes: "Imported case monitoring and epidemiological surveillance bulletins." },
  { name: "Médecins Sans Frontières (MSF)", type: "major international NGO", refresh: "hourly", notes: "Field reporting, outbreak response logistics and clinical response support in remote areas. NGO reports are never published directly without official validation cross-checking." },
  { name: "Global Infectious Disease and Epidemiology Network (GIDEON)", type: "authoritative epidemiology database", refresh: "hourly", notes: "Cross-country epidemiological validation and historical outbreak intelligence. Data must always be reconciled with official governmental or WHO-level reporting before publication." }
];

const DEMO_CASES = [
  { id: "ARG-2026-SE13-PBA", country: "Argentina", region: "Provincia de Buenos Aires", lat: -36.6769, lng: -60.5588, confirmed: 14, suspected: 0, deaths: null, healthStatus: "Aggregated official bulletin; individual status not public", source: "Argentina BEN SE 13 / official summary", lastUpdate: "2026-04-14", confidence: "official aggregate" },
  { id: "ARG-2026-SE13-SALTA", country: "Argentina", region: "Salta", lat: -24.7821, lng: -65.4232, confirmed: 12, suspected: 0, deaths: null, healthStatus: "Aggregated official bulletin; individual status not public", source: "Argentina BEN SE 13 / official summary", lastUpdate: "2026-04-14", confidence: "official aggregate" },
  { id: "ARG-2026-SE13-CHUBUT", country: "Argentina", region: "Chubut", lat: -43.2934, lng: -65.1115, confirmed: 2, suspected: 0, deaths: null, healthStatus: "Aggregated official bulletin; individual status not public", source: "Argentina BEN SE 13 / official summary", lastUpdate: "2026-04-14", confidence: "official aggregate" },
  { id: "ARG-2026-SE13-RN", country: "Argentina", region: "Río Negro", lat: -40.8135, lng: -63.0, confirmed: 2, suspected: 0, deaths: null, healthStatus: "Aggregated official bulletin; individual status not public", source: "Argentina BEN SE 13 / official summary", lastUpdate: "2026-04-14", confidence: "official aggregate" },
  { id: "CHL-2026-SE15", country: "Chile", region: "Chile - national aggregate", lat: -37.0, lng: -72.0, confirmed: 38, suspected: 0, deaths: null, healthStatus: "Aggregated official bulletin; regional detail to be parsed from PDF", source: "MINSAL Hantavirus SE 15 2026", lastUpdate: "2026-04-23", confidence: "official aggregate" },
  { id: "MV-HONDIUS-2026", country: "Multi-country / travel cluster", region: "Cruise ship MV Hondius", lat: 14.933, lng: -23.513, confirmed: 2, suspected: 5, deaths: 3, healthStatus: "1 critically ill; 3 mild/symptomatic/unknown in early official reports", source: "WHO DON / ECDC Threat Assessment", lastUpdate: "2026-05-04", confidence: "official cluster report" }
];

const DATA_URL = "data/cases.json";
const REFRESH_INTERVAL_MS = 1000 * 60 * 60;
const TILE_SIZE = 256;
const VIEW_PRESETS = {
  world: { label: "Mondo", centerLat: 18, centerLng: 0, zoom: 2 },
  americas: { label: "Americhe", centerLat: -12, centerLng: -72, zoom: 3 },
  southAmerica: { label: "Sud America", centerLat: -32, centerLng: -64, zoom: 5 },
  travelCluster: { label: "Cluster viaggio", centerLat: 8, centerLng: -35, zoom: 4 }
};
const MAP_BOUNDS = { minLat: -85, maxLat: 85, minLng: -180, maxLng: 180, minZoom: 2, maxZoom: 8 };

function clamp(number, min, max) { return Math.max(min, Math.min(max, number)); }
function normalizeLng(lng) { let value = Number(lng) || 0; while (value < -180) value += 360; while (value > 180) value -= 360; return value; }
function normalizeView(view) { return { centerLat: clamp(Number(view.centerLat) || 0, MAP_BOUNDS.minLat, MAP_BOUNDS.maxLat), centerLng: normalizeLng(view.centerLng), zoom: clamp(Math.round(Number(view.zoom) || MAP_BOUNDS.minZoom), MAP_BOUNDS.minZoom, MAP_BOUNDS.maxZoom) }; }
function latLngToPixel(lat, lng, zoom) { const safeLat = clamp(lat, MAP_BOUNDS.minLat, MAP_BOUNDS.maxLat); const sinLat = Math.sin((safeLat * Math.PI) / 180); const scale = TILE_SIZE * 2 ** zoom; return { x: ((normalizeLng(lng) + 180) / 360) * scale, y: (0.5 - Math.log((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)) * scale }; }
function pixelToLatLng(x, y, zoom) { const scale = TILE_SIZE * 2 ** zoom; const lng = (x / scale) * 360 - 180; const n = Math.PI - (2 * Math.PI * y) / scale; const lat = (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))); return { lat: clamp(lat, MAP_BOUNDS.minLat, MAP_BOUNDS.maxLat), lng: normalizeLng(lng) }; }
function getMarkerTone(item) { if (Number(item.deaths || 0) > 0) return "danger"; if (Number(item.suspected || 0) > 0) return "warning"; return "success"; }
function getMarkerClass(item) { const tone = getMarkerTone(item); if (tone === "danger") return "bg-red-600 ring-red-200"; if (tone === "warning") return "bg-orange-500 ring-orange-200"; return "bg-emerald-600 ring-emerald-200"; }
function getMarkerLabel(item) { const tone = getMarkerTone(item); if (tone === "danger") return "Include decessi"; if (tone === "warning") return "Include sospetti"; return "Confermati aggregati"; }
function totalEvents(item) { return Number(item.confirmed || 0) + Number(item.suspected || 0); }
function tileUrl(z, x, y) { const limit = 2 ** z; const wrappedX = ((x % limit) + limit) % limit; return `https://tile.openstreetmap.org/${z}/${wrappedX}/${y}.png`; }

function StatCard({ icon, value, label }) {
  return <div className="rounded-2xl bg-white p-5 shadow-sm border border-slate-100"><div className="text-2xl mb-2">{icon}</div><div className="text-3xl font-bold text-slate-900">{value}</div><div className="text-sm text-slate-500 mt-1">{label}</div></div>;
}

function InfoPanel({ selected }) {
  if (!selected) return <div className="rounded-2xl bg-white p-5 shadow-sm border border-slate-100"><p className="text-sm text-slate-500">Seleziona un marker sulla mappa.</p></div>;
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm border border-slate-100">
      <div className="flex items-start gap-3"><div className="text-2xl">📍</div><div><h2 className="text-xl font-bold text-slate-900">{selected.region}</h2><p className="text-sm text-slate-500">{selected.country}</p></div></div>
      <div className="grid grid-cols-3 gap-2 my-4 text-center">
        <div className="rounded-xl bg-slate-100 p-3"><div className="font-bold text-xl">{selected.confirmed}</div><div className="text-xs text-slate-500">confermati</div></div>
        <div className="rounded-xl bg-slate-100 p-3"><div className="font-bold text-xl">{selected.suspected}</div><div className="text-xs text-slate-500">sospetti</div></div>
        <div className="rounded-xl bg-slate-100 p-3"><div className="font-bold text-xl">{selected.deaths ?? "n/d"}</div><div className="text-xs text-slate-500">decessi</div></div>
      </div>
      <p className="text-sm"><strong>Stato salute:</strong> {selected.healthStatus}</p>
      <p className="text-sm mt-2"><strong>Fonte:</strong> {selected.source}</p>
      <p className="text-sm mt-2"><strong>Aggiornato:</strong> {selected.lastUpdate}</p>
      <p className="text-xs text-slate-500 mt-3">Livello dato: {selected.confidence}</p>
      <p className="text-xs text-emerald-700 mt-1 font-medium">✓ {selected.validationLevel || "Validated against official monitored sources"}</p>
    </div>
  );
}

function MapControls({ activePreset, onPreset, onZoom }) {
  return <div className="rounded-2xl bg-white p-3 shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center md:justify-between gap-3"><div className="flex flex-wrap gap-2">{Object.entries(VIEW_PRESETS).map(([key, preset]) => <button key={key} type="button" onClick={() => onPreset(key)} className={`rounded-xl px-3 py-2 text-xs font-semibold hover:bg-slate-200 ${activePreset === key ? "bg-slate-900 text-white hover:bg-slate-700" : "bg-slate-100 text-slate-700"}`}>{preset.label}</button>)}</div><div className="flex items-center gap-2"><button type="button" onClick={() => onZoom(-1)} className="rounded-xl bg-slate-100 hover:bg-slate-200 px-4 py-2 font-bold">−</button><button type="button" onClick={() => onZoom(1)} className="rounded-xl bg-slate-100 hover:bg-slate-200 px-4 py-2 font-bold">+</button></div></div>;
}

function TileLayer({ view, width, height }) {
  const normalized = normalizeView(view);
  const zoom = normalized.zoom;
  const center = latLngToPixel(normalized.centerLat, normalized.centerLng, zoom);
  const startX = Math.floor((center.x - width / 2) / TILE_SIZE) - 1;
  const endX = Math.floor((center.x + width / 2) / TILE_SIZE) + 1;
  const startY = Math.max(0, Math.floor((center.y - height / 2) / TILE_SIZE) - 1);
  const endY = Math.min(2 ** zoom - 1, Math.floor((center.y + height / 2) / TILE_SIZE) + 1);
  const tiles = [];
  for (let x = startX; x <= endX; x += 1) for (let y = startY; y <= endY; y += 1) tiles.push({ x, y, left: x * TILE_SIZE - center.x + width / 2, top: y * TILE_SIZE - center.y + height / 2 });
  return <>{tiles.map((tile) => <img key={`${zoom}-${tile.x}-${tile.y}`} src={tileUrl(zoom, tile.x, tile.y)} alt="" draggable="false" className="absolute select-none pointer-events-none" style={{ width: TILE_SIZE, height: TILE_SIZE, left: tile.left, top: tile.top }} />)}</>;
}

function InteractiveMap({ cases, selected, onSelect, view, setView, activePreset, setActivePreset }) {
  const mapRef = useRef(null);
  const dragRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 900, height: 620 });
  useEffect(() => { if (!mapRef.current) return undefined; const element = mapRef.current; const update = () => setDimensions({ width: element.clientWidth || 900, height: element.clientHeight || 620 }); update(); const observer = new ResizeObserver(update); observer.observe(element); return () => observer.disconnect(); }, []);
  const normalized = normalizeView(view);
  const centerPixel = latLngToPixel(normalized.centerLat, normalized.centerLng, normalized.zoom);
  const projectedCases = useMemo(() => cases.map((item) => { const pixel = latLngToPixel(item.lat, item.lng, normalized.zoom); let x = pixel.x - centerPixel.x + dimensions.width / 2; const worldWidth = TILE_SIZE * 2 ** normalized.zoom; if (x < -worldWidth / 2) x += worldWidth; if (x > worldWidth / 2) x -= worldWidth; const y = pixel.y - centerPixel.y + dimensions.height / 2; return { item, x, y, visible: x >= -40 && x <= dimensions.width + 40 && y >= -40 && y <= dimensions.height + 40 }; }), [cases, normalized.centerLat, normalized.centerLng, normalized.zoom, centerPixel.x, centerPixel.y, dimensions.width, dimensions.height]);
  function updateView(nextView) { setView(normalizeView(nextView)); }
  function applyPreset(key) { setActivePreset(key); updateView(VIEW_PRESETS[key]); }
  function zoomBy(delta) { setActivePreset("custom"); updateView({ ...view, zoom: view.zoom + delta }); }
  function handlePointerDown(event) { if (!mapRef.current) return; event.currentTarget.setPointerCapture?.(event.pointerId); dragRef.current = { startX: event.clientX, startY: event.clientY, startCenter: latLngToPixel(normalized.centerLat, normalized.centerLng, normalized.zoom), startZoom: normalized.zoom }; }
  function handlePointerMove(event) { if (!dragRef.current) return; const nextPixel = { x: dragRef.current.startCenter.x - (event.clientX - dragRef.current.startX), y: dragRef.current.startCenter.y - (event.clientY - dragRef.current.startY) }; const nextCenter = pixelToLatLng(nextPixel.x, nextPixel.y, dragRef.current.startZoom); setActivePreset("custom"); updateView({ centerLat: nextCenter.lat, centerLng: nextCenter.lng, zoom: dragRef.current.startZoom }); }
  function handlePointerUp(event) { event.currentTarget.releasePointerCapture?.(event.pointerId); dragRef.current = null; }
  function handleWheel(event) { event.preventDefault(); zoomBy(event.deltaY < 0 ? 1 : -1); }
  return (
    <>
      <MapControls activePreset={activePreset} onPreset={applyPreset} onZoom={zoomBy} />
      <div ref={mapRef} className="relative h-[620px] overflow-hidden cursor-grab active:cursor-grabbing select-none bg-slate-200 rounded-2xl border border-slate-100" onPointerDown={handlePointerDown} onPointerMove={handlePointerMove} onPointerUp={handlePointerUp} onPointerCancel={handlePointerUp} onWheel={handleWheel} role="application" aria-label="Mappa interattiva dei casi Hantavirus Andes">
        <TileLayer view={normalized} width={dimensions.width} height={dimensions.height} />
        {projectedCases.map(({ item, x, y, visible }) => {
          if (!visible) return null;
          const size = Math.min(48, 20 + Math.sqrt(totalEvents(item)) * 4);
          const isSelected = selected?.id === item.id;
          return <button type="button" key={item.id} className={`absolute z-20 -translate-x-1/2 -translate-y-1/2 ${getMarkerClass(item)} text-white rounded-full shadow-lg border-4 border-white ring-4 flex items-center justify-center hover:scale-110 transition-transform focus:outline-none focus:ring-slate-400 ${isSelected ? "scale-110" : ""}`} style={{ left: x, top: y, width: size, height: size }} onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); onSelect(item); }} aria-label={`${item.region}: ${item.confirmed} casi confermati. ${getMarkerLabel(item)}`} title={`${item.region}: ${item.confirmed} confermati`}><span className="text-xs font-bold">{item.confirmed}</span></button>;
        })}
      </div>
      <p className="mt-2 text-[11px] text-slate-500">© OpenStreetMap contributors</p>
    </>
  );
}

export default function HantavirusAndesLiveMapApp() {
  const [cases, setCases] = useState(DEMO_CASES);
  const [selected, setSelected] = useState(DEMO_CASES[0]);
  const [loading, setLoading] = useState(false);
  const [lastSync, setLastSync] = useState(new Date().toISOString());
  const [view, setView] = useState(VIEW_PRESETS.world);
  const [activePreset, setActivePreset] = useState("world");

  function validateCasesWithOfficialSources(cases) {
    return cases.filter((item) => {
      const sourceText = String(item.source || "").toLowerCase();
      const hasOfficialValidation = sourceText.includes("who") || sourceText.includes("paho") || sourceText.includes("minsal") || sourceText.includes("minister") || sourceText.includes("cdc") || sourceText.includes("ecdc") || sourceText.includes("instituto") || sourceText.includes("isp") || sourceText.includes("ben");
      return SOURCE_VALIDATION_RULES.allowPublicationWithoutOfficialSource || hasOfficialValidation;
    }).map((item) => ({ ...item, validated: true, validationLevel: "Cross-checked with official monitored sources" }));
  }

  async function refreshData() {
    setLoading(true);
    try {
      const response = await fetch(`${DATA_URL}?t=${Date.now()}`, { cache: "no-store" });
      if (!response.ok) throw new Error(`Unable to load ${DATA_URL}`);
      const data = await response.json();
      if (Array.isArray(data.cases) && data.cases.length > 0) {
        const validatedCases = validateCasesWithOfficialSources(data.cases);
        setCases(validatedCases);
        setSelected((current) => validatedCases.find((item) => item.id === current?.id) || validatedCases[0]);
      }
      setLastSync(data.lastSync || new Date().toISOString());
    } catch {
      const validatedDemoCases = validateCasesWithOfficialSources(DEMO_CASES);
      setCases(validatedDemoCases);
      setSelected((current) => validatedDemoCases.find((item) => item.id === current?.id) || validatedDemoCases[0]);
      setLastSync(new Date().toISOString());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { refreshData(); const timer = window.setInterval(refreshData, REFRESH_INTERVAL_MS); return () => window.clearInterval(timer); }, []);
  const filtered = useMemo(() => cases, [cases]);
  const totals = useMemo(() => filtered.reduce((acc, item) => ({ confirmed: acc.confirmed + Number(item.confirmed || 0), suspected: acc.suspected + Number(item.suspected || 0), deaths: acc.deaths + Number(item.deaths || 0) }), { confirmed: 0, suspected: 0, deaths: 0 }), [filtered]);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 text-slate-900">
      <div className="max-w-7xl mx-auto space-y-5">
        <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div><p className="text-sm font-medium text-slate-500">Prototype dashboard epidemiologico</p><h1 className="text-3xl md:text-4xl font-bold tracking-tight">Hantavirus Andes · Live Map</h1></div>
          <button type="button" onClick={refreshData} className="rounded-2xl bg-slate-900 text-white px-4 py-3 shadow-sm hover:bg-slate-700 disabled:opacity-60" disabled={loading}>{loading ? "Aggiornamento…" : "↻ Aggiorna ora"}</button>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatCard icon="🧬" value={totals.confirmed} label="Casi confermati visualizzati" />
          <StatCard icon="⚠️" value={totals.suspected} label="Casi sospetti visualizzati" />
          <StatCard icon="☠️" value={totals.deaths} label="Decessi pubblicati" />
          <StatCard icon="🕒" value={new Date(lastSync).toLocaleTimeString()} label="Ultimo aggiornamento automatico" />
        </section>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <section className="lg:col-span-2 space-y-4">
            <InteractiveMap cases={filtered} selected={selected} onSelect={setSelected} view={view} setView={setView} activePreset={activePreset} setActivePreset={setActivePreset} />
          </section>
          <aside className="space-y-5">
            <InfoPanel selected={selected} />
            <div className="rounded-2xl bg-white p-5 shadow-sm border border-slate-100">
              <h3 className="font-bold mb-3">Fonti monitorate e validate</h3>
              <div className="space-y-3 max-h-64 overflow-auto pr-1">
                {SOURCES.map((source) => <div key={source.name} className="border border-slate-100 rounded-xl p-3 bg-white"><div className="font-semibold text-sm">{source.name}</div><div className="text-xs text-slate-500">{source.type} · refresh {source.refresh} · official cross-check enabled</div><div className="text-xs mt-1 text-slate-600">{source.notes}</div></div>)}
              </div>
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}
