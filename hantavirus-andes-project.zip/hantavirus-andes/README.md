# Hantavirus Andes · Live Map

Dashboard pubblica per visualizzare casi aggregati e validati relativi ad Hantavirus Andes.

## Sviluppo locale

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Aggiornamento dati

```bash
npm run update:data
```

## Pubblicazione GitHub Pages

Il workflow `.github/workflows/deploy.yml` pubblica automaticamente il sito su GitHub Pages dopo ogni push su `main`.

## Aggiornamento automatico orario

Il workflow `.github/workflows/update-data.yml` aggiorna `public/data/cases.json` ogni ora.

## Validazione dati

I dati non ufficiali non devono essere pubblicati direttamente. Ogni record deve essere confrontato con fonti ufficiali monitorate: WHO, PAHO, ministeri della salute, CDC, ECDC, istituti sanitari nazionali.
